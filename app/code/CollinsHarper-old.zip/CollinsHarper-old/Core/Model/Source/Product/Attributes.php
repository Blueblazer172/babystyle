<?php

/**
 * Copyright © 2015 Collins Harper. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace CollinsHarper\Core\Model\Source\Product;

/**
 * Source model for Product Attributes List
 */
class Attributes implements \Magento\Framework\Option\ArrayInterface
{
    /**
     * @var \Magento\Catalog\Model\ResourceModel\Product\Attribute\CollectionFactory
     */
    private $collectionFactory;

    /**
     * @param \Magento\Catalog\Model\ResourceModel\Product\Attribute\CollectionFactory $collectionFactory
     */
    public function __construct(
        \Magento\Catalog\Model\ResourceModel\Product\Attribute\CollectionFactory $collectionFactory
    ) {
        $this->collectionFactory = $collectionFactory;
    }

    /**
     * {@inheritdoc}
     */
    public function toOptionArray()
    {
        $collection = $this->collectionFactory->create()->addVisibleFilter();
        /*
         * @TODO Sort by label
         */
        $array = [
            ['label' => __('Not Selected'), 'value' => '']
        ];
        foreach ($collection as $attribute) {
            $array[] = [
                'label' => $attribute->getFrontendLabel(), 'value' => $attribute->getAttributeCode()
            ];
        }
        return $array;
    }
}
