<?php
/**
* Copyright © 2016 Collinsharper. All rights reserved.
* See COPYING.txt for license details.
*/

namespace Collinsharper\Moneris\Setup;
use Magento\Framework\Setup\UpgradeSchemaInterface;
use Magento\Framework\Setup\ModuleContextInterface;
use Magento\Framework\Setup\SchemaSetupInterface;
class UpgradeSchema implements  UpgradeSchemaInterface
{
    public function upgrade(SchemaSetupInterface $installer, ModuleContextInterface $context)
    {
        $installer->startSetup();
        if (version_compare($context->getVersion(), '2.1.1', '<')) {
            $installer->getConnection()->dropTable($installer->getTable('collinsharper_moneris_payment_vault'));
            $table = $installer->getTable('collinsharper_moneris_payment_vault');
            if ($installer->getConnection()->isTableExists($table) != true) {
               $table = $installer->getConnection()->newTable($table)
                   ->addColumn(
                       'vault_id',
                       \Magento\Framework\DB\Ddl\Table::TYPE_INTEGER,
                       null,
                       array(
                           'identity' => true,
                           'unsigned' => true,
                           'nullable' => false,
                           'primary' => true
                       ),
                       'Vault Id'
                   )
                   ->addColumn(
                       'created_date',
                       \Magento\Framework\DB\Ddl\Table::TYPE_DATETIME,
                       null,
                       array(
                           'nullable' => true
                       ),
                       'Created Date'
                   )
                   ->addColumn(
                       'customer_id',
                       \Magento\Framework\DB\Ddl\Table::TYPE_INTEGER,
                       null,
                       array(
                           'nullable' => false,
                           'default' => '0'
                       ),
                       'Customer Id'
                   )
                   ->addColumn(
                       'data_key',
                       \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
                       null,
                       array(
                           'nullable' => false,
                       ),
                       'Data Key'
                   )
                   ->setComment('Vault Table')
                   ->setOption('type', 'InnoDB')
                   ->setOption('charset', 'utf8');
                   $installer->getConnection()->createTable($table);
            }
            
            $installer->endSetup();
        }
        
        if (version_compare($context->getVersion(), '2.1.2', '<')) {
            $table = $installer->getTable('collinsharper_moneris_payment_vault');
            if ($installer->getConnection()->isTableExists($table) == true) {
                $connection = $installer->getConnection();
                $connection->addColumn(
                    $table,
                    'customer_email', \Magento\Framework\DB\Ddl\Table::TYPE_TEXT, null,
                    array('nullable' => false),
                    'Customer Email'
                );
            }
            
            $installer->endSetup();
        }
        
        if (version_compare($context->getVersion(), '2.1.2', '<')) {
            $table = $installer->getTable('collinsharper_moneris_payment_vault');
            if ($installer->getConnection()->isTableExists($table) == true) {
                $connection = $installer->getConnection();
                $connection->addColumn(
                    $table,
                    'store_id', \Magento\Framework\DB\Ddl\Table::TYPE_INTEGER, null,
                    array('nullable' => false),
                    'Store Id'
                );
                $connection->addColumn(
                    $table,
                    'card_default', \Magento\Framework\DB\Ddl\Table::TYPE_INTEGER, null,
                    array(
                        'nullable' => false,
                        'default' => '0'
                    ),
                    'Cart Default'
                );
                $connection->addColumn(
                    $table,
                    'card_expire', \Magento\Framework\DB\Ddl\Table::TYPE_TEXT, null,
                    array(
                        'nullable' => false,
                    ),
                    'Cart Expire'
                );
                $connection->addColumn(
                    $table,
                    'cc_exp_month', \Magento\Framework\DB\Ddl\Table::TYPE_TEXT, null,
                    array(
                        'nullable' => false,
                    ),
                    'Cart Expire Month'
                );
                $connection->addColumn(
                    $table,
                    'cc_exp_year', \Magento\Framework\DB\Ddl\Table::TYPE_TEXT, null,
                    array(
                        'nullable' => false,
                    ),
                    'Cart Expire Year'
                );
                $connection->addColumn(
                    $table,
                    'cardholder', \Magento\Framework\DB\Ddl\Table::TYPE_TEXT, null,
                    array(
                        'nullable' => false,
                    ),
                    'Cart Card Holder'
                );
                $connection->addColumn(
                    $table,
                    'card_type', \Magento\Framework\DB\Ddl\Table::TYPE_TEXT, null,
                    array(
                        'nullable' => false,
                    ),
                    'Cart Type'
                );
                $connection->addColumn(
                    $table,
                    'cc_last', \Magento\Framework\DB\Ddl\Table::TYPE_TEXT, null,
                    array(
                        'nullable' => false,
                    ),
                    'Cc Last 4'
                );
                $connection->addColumn(
                    $table,
                    'updated_date', \Magento\Framework\DB\Ddl\Table::TYPE_DATETIME, null,
                    array(
                        'nullable' => false,
                    ),
                    'Updated Date'
                );
                ;
            }
        }
        if (version_compare($context->getVersion(), '2.1.3', '<')) {
            $quote = 'quote';
            $installer->getConnection()
            ->addColumn(
                $installer->getTable($quote),
                'bank_transaction_id',
                array(
                    'type' => \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
                    'length' => 255,
                    'comment' =>'Bank Transaction Id'
                )
            );
            $installer->endSetup();
        }
        $installer->endSetup();
    }
}
