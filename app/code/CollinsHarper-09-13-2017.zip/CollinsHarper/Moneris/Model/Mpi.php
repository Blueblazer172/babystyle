<?php
/**
 * Copyright © 2016 CollinsHarper. All rights reserved.
 * See LICENSE.txt for license details.
 */
namespace CollinsHarper\Moneris\Model;

use CollinsHarper\Moneris\Model\AbstractModel;
use Magento\Framework\DataObject;

/**
 * Moneres OnSite Payment Method model.
 * @SuppressWarnings(PHPMD.TooManyFields)
 * @SuppressWarnings(PHPMD.CouplingBetweenObjects)
 * @SuppressWarnings(PHPMD.ExcessiveClassComplexity)
 */
class Mpi extends AbstractModel
{

    public function buildTransactionArray()
    {
        throw new \Exception('This should be overridden in the extending class.');
    }

    public function post($txnArray = null)
    {
        if (!$txnArray) {
            $txnArray = $this->buildTransactionArray();
        }

        $payment = $this->getPayment();
        $methodCode = $payment->getMethodInstance()->getCode();
        $storeId = $this->getHelper()->getConfigData("payment/".$methodCode."/login", true);
        $apiToken =  $this->getHelper()->getConfigData("payment/".$methodCode."/password", true);

        $mpgTxn = new \Moneris_MpgTransaction($txnArray);
        $mpgRequest = new \Moneris_MpgRequest($mpgTxn);

        $mpgRequest->setProcCountryCode("CA");
        if ($this->getHelper()->isUsApi()) {
            $mpgRequest->setProcCountryCode("US"); //"US" for sending transaction to US environment
        }
        
        if ($this->getHelper()->isTest()) {
            $mpgRequest->setTestMode(true); //false or comment out this line for production transactions
        }
        
        $mpiHttpsPost = new \Moneris_MpgHttpsPost($storeId, $apiToken, $mpgRequest);
        $mpiResponse = $mpiHttpsPost->getMpgResponse();

        return $mpiResponse;
    }
}
