 /**
 * Copyright © 2016 Collinsharper. All rights reserved.
 * See COPYING.txt for license details.
 */
var config = {
    map: {
        '*': {
            transparent: 'Magento_Payment/transparent'
        }
    }
};


