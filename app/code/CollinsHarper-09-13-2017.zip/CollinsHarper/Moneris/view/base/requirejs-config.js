 /**
 * Copyright © 2016 Collinsharper. All rights reserved.
 * See COPYING.txt for license details.
 */
var config = {
    map: {
        '*': {
            'Magento_Payment/js/model/credit-card-validation/credit-card-number-validator': 'CollinsHarper_Moneris/js/model/credit-card-number-validator',
            'mage/validation': 'CollinsHarper_Moneris/js/mage/validation'
        }
    }
};


