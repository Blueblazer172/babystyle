<?php



class Moneris_MpiTransaction{

 var $txn;

 function Moneris_MpiTransaction($txn){

  $this->txn=$txn; 

 }

function getTransaction(){

 return $this->txn;
} 

}//end class