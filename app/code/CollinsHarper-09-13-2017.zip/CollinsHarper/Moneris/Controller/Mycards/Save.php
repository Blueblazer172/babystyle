<?php
/**
 * Copyright © 2016 CollinsHarper. All rights reserved.
 * See LICENSE.txt for license details.
 */
namespace CollinsHarper\Moneris\Controller\Mycards;

use CollinsHarper\Moneris\Controller\AbstractMycards;

class Save extends AbstractMycards
{
    protected function _execute()
    {
        $request = $this->getRequest();
        $data = $request->getParams();
        $this->vaultSaveService->process($data);
        $this->messageManager->addSuccessMessage(__('Your Credit Card has been saved successfully.'));
        return $this->resultRedirectFactory->create()->setPath('*/*/');
    }
}
