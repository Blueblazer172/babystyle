<?php
/**
 * Copyright © 2015 Collins Harper. All rights reserved.
 * See COPYING.txt for license details.
 */
return array(
    'firstname' => 'Watson',
    'lastname' => 'Harper',
    'company' => 'Collins Harper',
    'street' => '123 Fake Street',
    'city' => 'La Quinta',
    'Region_code' => 'CA',
    'country' => 'USA',
    'telephone' => '8663259627',
    'fax' => 'reallly? who uses faxews?'
);