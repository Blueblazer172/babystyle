<?php
/**
 * Copyright © 2015 Collins Harper. All rights reserved.
 * See COPYING.txt for license details.
 */
return array(
    'cc_number' => '4242424242424242',
    'cc_cid' => '123',
    'cc_exp_month' => 11,
    'cc_exp_year' => date('Y')+3,
);