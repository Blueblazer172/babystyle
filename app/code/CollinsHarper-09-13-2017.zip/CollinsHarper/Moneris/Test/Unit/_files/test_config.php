<?php
/**
 * Copyright © 2015 Collins Harper. All rights reserved.
 * See COPYING.txt for license details.
 */
return array(
    'payment/chmoneriscc/test' => true,
    'payment/chmoneriscc/debug' => true,
    'payment/chmoneriscc/login' => 'store5',
    'payment/chmoneriscc/password' => 'yesguy',
);