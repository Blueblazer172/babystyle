<?php
/**
 * Copyright © 2015 Collins Harper. All rights reserved.
 * See COPYING.txt for license details.
 */
return array(
    'customer_id' => '2',
    'customer_email' => 'support@collinsharper.com',
    'increment_id' => '2w3456789w3',
    'entity_id' => 345,
    'granttotal' => 1.00,
    'grant_total' => 1.00,
    'base_grand_total' => 1.00,
);