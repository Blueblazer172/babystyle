<?php
/**
 * Copyright © 2016 Collinsharper. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace CollinsHarper\Moneris\Block\Info;

class Moneris extends \Magento\Payment\Block\Info
{

}
