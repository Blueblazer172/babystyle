<?php
/**
 * Copyright © 2016 Collinsharper. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace CollinsHarper\Moneris\Block\Form;

class Moneris extends \Magento\Payment\Block\Transparent\Info
{

}
