<?php

/**
 * Copyright © 2015 Collins Harper. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace CollinsHarper\Core\Helper;

use Magento\Framework\ObjectManagerInterface;
use \Magento\Framework\App\Helper\Context;

/**
 * Measure Unit helper
 * @SuppressWarnings(PHPMD.TooManyFields)
 * @SuppressWarnings(PHPMD.CouplingBetweenObjects)
 */
class Measure extends \Magento\Framework\App\Helper\AbstractHelper
{
    const XML_PATH_DEFAULT_LENGTH = 'catalog/chcore/default_length';
    const XML_PATH_DEFAULT_WIDTH = 'catalog/chcore/default_width';
    const XML_PATH_DEFAULT_HEIGHT = 'catalog/chcore/default_height';
    const XML_PATH_DEFAULT_WEIGHT_UNIT = 'catalog/chcore/weight_unit';
    const XML_PATH_DEFAULT_MEASURE_UNIT = 'catalog/chcore/measure_unit';
    const XML_PATH_PRODUCT_SHIPPING_LENGTH = 'catalog/chcore/shipping_length';
    const XML_PATH_PRODUCT_SHIPPING_WIDTH = 'catalog/chcore/shipping_width';
    const XML_PATH_PRODUCT_SHIPPING_HEIGHT = 'catalog/chcore/shipping_height';
    const CARRIER_HELPER_CLASS = '\Magento\Shipping\Helper\Carrier';

    /**
     * @var ObjectManagerInterface
     */
    protected $objectManager;

    /**
     * Carrier helper
     * @var \Magento\Shipping\Helper\Carrier
     */
    protected $carrierHelper;

    /**
     * @var \Zend_Measure_Weight
     */
    private $zendMeasureWeight;

    /**
     * @var \Zend_Measure_Length
     */
    private $zendMeasureLength;

    /**
     * Measure constructor.
     * @param Context $context
     * @param \Magento\Shipping\Helper\Carrier $carrierHelper
     */
    public function __construct(
        \Magento\Framework\App\Helper\Context $context,
        \Magento\Shipping\Helper\Carrier $carrierHelper,
        \Zend_Measure_Weight $zendMeasureWeight,
        \Zend_Measure_Length $zendMeasureLength
    ) {
        $this->carrierHelper = $carrierHelper;
        $this->zendMeasureWeight = $zendMeasureWeight;
        $this->zendMeasureLength = $zendMeasureLength;
        parent::__construct($context);
    }

    public function getCarrierHelper()
    {
        return $this->carrierHelper;
    }

    /**
     * Retrieve converted Weight
     *
     * @param   float $value value to convert
     * @param   string $fromUnit From unit
     * @param   string $toUnit Destination unit
     * @return  float
     */
    public function getConvertedWeight($value, $fromUnit, $toUnit)
    {
        if ($value) {
            $this->zendMeasureWeight->setValue($value, $fromUnit);
            $this->zendMeasureWeight->setType($toUnit);

            return $this->zendMeasureWeight->getValue();
        }
        return null;
    }

    /**
     * Retrieve converted Weight
     *
     * @param   float $value value to convert
     * @param   string $fromUnit From unit
     * @param   string $toUnit Destination unit
     * @return  float
     */
    public function getConvertedLength($value, $fromUnit, $toUnit)
    {

        if ($value) {
            $this->zendMeasureLength->setValue($value, $fromUnit);
            $this->zendMeasureLength->setType($toUnit);
            return $this->zendMeasureLength->getValue();
        }
        return null;
    }

    /**
     * Clear measure objects
     */
    public function __destruct()
    {
        $this->zendMeasureLength = null;
        $this->zendMeasureWeight = null;
    }
}
